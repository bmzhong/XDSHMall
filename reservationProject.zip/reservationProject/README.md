# SpringBoot校园二手交易平台


#开发技术
   #前端
     bootstarp框架   html页面
   #后端技术 
     SpringBoot SpringMvc jpa 
     
#开发工具
  eclipse或者idea
  jdk1.8  mysql5点几版本 （低于或者高于jar包依赖版本达不到）
  
  maven环境  maven3.5+
  