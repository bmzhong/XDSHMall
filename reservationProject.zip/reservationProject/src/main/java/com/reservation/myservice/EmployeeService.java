package com.reservation.myservice;

import com.reservation.vo.RegisterVO;

public interface EmployeeService {
    String registerEmployee(RegisterVO registerVO);
}
