package com.reservation.myservice;

import com.reservation.vo.RegisterVO;

public interface AdminService {

    String registerAdmin(RegisterVO registerVO);
}
