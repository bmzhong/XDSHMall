package com.reservation.web.user;

import com.reservation.bean.Clerk;
import com.reservation.entity.AdminUser;
import com.reservation.entity.pojo.ResultBean;
import com.reservation.myservice.AdminService;
import com.reservation.myservice.ClerkService;
import com.reservation.myservice.EmployeeService;
import com.reservation.service.AdminUserService;
import com.reservation.service.exception.LoginException;
import com.reservation.vo.RegisterVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.reservation.entity.User;
import com.reservation.service.UserService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    AdminService adminService;

    @Autowired
    ClerkService clerkService;

    @Autowired
    EmployeeService employeeService;

    @Autowired
    private UserService userService;

    @Autowired
    private AdminUserService adminUserService;

    /**
     * 打开注册页面
     *
     * @return
     */
    @RequestMapping("/toRegister.html")
    public String toRegister() {
        return "mall/user/register";
    }

    /**
     * 打开登录页面
     *
     * @return
     */
    @RequestMapping("/toLogin.html")
    public String toLogin() {
        return "mall/user/login";
    }

    /**
     * 登录
     *
     * @param username
     * @param password
     */
    @RequestMapping("/login.do")
    public void login(String username,
                      String password,
                      String personnel,
                      HttpServletRequest request,
                      HttpServletResponse response) throws IOException {
        if (personnel.equals("餐厅经理")) {
            AdminUser adminUser = adminUserService.checkLogin(request, username, password);
            response.sendRedirect("/mall/admin/toIndex.html");
        } else {
            User user = userService.checkLogin(username, password);
            if (user != null) {
                //登录成功 重定向到首页
                request.getSession().setAttribute("user", user);
                response.sendRedirect("/mall/index.html");
            } else {
                throw new LoginException("登录失败！ 用户名或者密码错误");
            }
        }
    }

    /**
     * 注册
     */
    @RequestMapping("/register.do")
    public void register(
//                         String username,
//                         String password,
//                         String name,
//                         String phone,
//                         String email,
//                         String addr,
//                         String personnel,
            RegisterVO registerVO,
            HttpServletResponse response) throws IOException {
        System.out.println(registerVO.toString());
        if (registerVO.getPersonnel().equals("顾客")) {
            User user = new User();
            user.setUsername(registerVO.getUsername());
            user.setPhone(registerVO.getPhone());
            user.setPassword(registerVO.getPassword());
            user.setName(registerVO.getName());
            user.setEmail(registerVO.getEmail());
            user.setAddr(registerVO.getAddress());
            userService.create(user);
        } else {
            String resultMsg = null;
            if (registerVO.getPersonnel().equals("餐厅员工")) {
                resultMsg = adminService.registerAdmin(registerVO);
                resultMsg = employeeService.registerEmployee(registerVO);
            } else if (registerVO.getPersonnel().equals("送餐员")) {
                resultMsg = adminService.registerAdmin(registerVO);
                resultMsg = clerkService.registerClerk(registerVO);
            } else if (registerVO.getPersonnel().equals("餐厅经理")) {
                resultMsg = adminService.registerAdmin(registerVO);
            }
            System.out.println(resultMsg);
        }
        // 注册完成后重定向到登录页面
        response.sendRedirect("/mall/user/toLogin.html");
    }

    /**
     * 登出
     */
    @RequestMapping("/logout.do")
    public void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
        request.getSession().removeAttribute("user");
        response.sendRedirect("/mall/index.html");
    }

    /**
     * 验证用户名是否唯一
     *
     * @param username
     * @return
     */
    @ResponseBody
    @RequestMapping("/checkUsername.do")
    public ResultBean<Boolean> checkUsername(String username) {
        List<User> users = userService.findByUsername(username);
        if (users == null || users.isEmpty()) {
            return new ResultBean<>(true);
        }
        return new ResultBean<>(false);
    }

    /**
     * 如发生错误 转发到这页面
     *
     * @param response
     * @param request
     * @return
     */
    @RequestMapping("/error.html")
    public String error(HttpServletResponse response, HttpServletRequest request) {
        return "error";
    }
}
